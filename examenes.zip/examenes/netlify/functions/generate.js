// Función de Netlify: llama a Claude de forma segura (la clave nunca llega al navegador).
exports.handler = async (event) => {
  if (event.httpMethod !== "POST") return { statusCode: 405, body: "Método no permitido" };
  const key = process.env.ANTHROPIC_API_KEY;
  if (!key) return { statusCode: 500, body: JSON.stringify({ error: "Falta la variable ANTHROPIC_API_KEY en Netlify." }) };
  try {
    const { text, pdfs = [], opts } = JSON.parse(event.body);
    const prompt = `Eres profesor/a. Crea un examen EN ESPAÑOL basado SOLO en el material adjunto.
Nivel: ${opts.nivel}. Preguntas: ${opts.test} de opción múltiple (4 opciones), ${opts.vf} de verdadero/falso, ${opts.corta} de respuesta corta.
Responde SOLO con JSON válido, sin markdown, con esta forma:
{"titulo":"...","preguntas":[{"tipo":"test","enunciado":"...","opciones":["...","...","...","..."],"correcta":0,"explicacion":"..."},{"tipo":"vf","enunciado":"...","correcta":true,"explicacion":"..."},{"tipo":"corta","enunciado":"...","respuesta":"...","explicacion":"..."}]}

MATERIAL:
${text || "(ver documentos adjuntos)"}`;
    const content = [...pdfs.map(d => ({ type: "document", source: { type: "base64", media_type: "application/pdf", data: d } })), { type: "text", text: prompt }];
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "content-type": "application/json", "x-api-key": key, "anthropic-version": "2023-06-01" },
      body: JSON.stringify({ model: "claude-sonnet-5-5", max_tokens: 3500, messages: [{ role: "user", content }] })
    });
    const data = await r.json();
    if (!r.ok) return { statusCode: r.status, body: JSON.stringify({ error: data.error?.message || "Error de la API" }) };
    const raw = data.content.map(c => c.text || "").join("").replace(/```json|```/g, "").trim();
    return { statusCode: 200, headers: { "content-type": "application/json" }, body: JSON.stringify(JSON.parse(raw)) };
  } catch (e) {
    return { statusCode: 500, body: JSON.stringify({ error: "No se pudo generar el examen: " + e.message }) };
  }
};
